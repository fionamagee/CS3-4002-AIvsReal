# Sample Images

This folder is a placeholder for a small sample subset (~50 real and ~50 AI-generated images, one batch from each generator) so students can verify their pipeline runs end-to-end before downloading the full ~96,000-image dataset from Hugging Face.

To populate this folder, run `python ../download_dataset.py` and copy the first ~10 examples per Label_B class here, or download the small sample we provide via the dataset card on Hugging Face.
