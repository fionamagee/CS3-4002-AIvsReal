# Defactify Image Dataset — Data Dictionary

The Defactify Image Dataset is a curated collection of real and AI-generated images paired with textual captions and source labels. It supports both binary classification (real vs. AI) and multi-class classification (which generative model produced the image).

**Source**: https://huggingface.co/datasets/Rajarshi-Roy-research/Defactify_Image_Dataset

| Column   | Data Type | Description                                          | Possible Values |
|----------|-----------|------------------------------------------------------|-----------------|
| Caption  | string    | Text description of the image content                | e.g., "Two tall giraffes standing next to each other on a field." |
| Image    | image     | The image associated with the caption                | PIL image / image bytes |
| Label_A  | int32     | Binary indicator: real or AI-generated               | 0 = Real, 1 = AI-generated |
| Label_B  | int32     | Source model that generated the image                | 0 = Real, 1 = SD2.1, 2 = SDXL, 3 = SD3, 4 = DALL·E 3, 5 = Midjourney |

## Class balance
The full dataset contains roughly 96,000 images, distributed approximately evenly across the six classes (~16,000 each), giving a 1:5 real-to-AI ratio overall. Students should consider class weighting or balanced sampling during training.

## Why captions matter
The captions used for AI-generated images were derived from the captions of real COCO images. This means the *content* (subject matter) is approximately matched across classes — what differs is the *generation process*. This is what makes the dataset suitable for training a detector that focuses on artifacts of generation rather than content.
