"""
download_dataset.py
-------------------
Downloads the Defactify Image Dataset from Hugging Face for the
DS 4002 case study on detecting AI-generated images.

Usage:
    pip install datasets
    python download_dataset.py

This will create a local copy of the dataset in ./defactify_data/
The full dataset is large (~96k images). For quick experimentation,
use the streaming option or the small sample subset in ./sample_images/.
"""

from datasets import load_dataset
import os

OUT_DIR = "defactify_data"

def main():
    os.makedirs(OUT_DIR, exist_ok=True)
    print("Downloading Defactify Image Dataset from Hugging Face...")
    ds = load_dataset("Rajarshi-Roy-research/Defactify_Image_Dataset")

    # Print summary
    for split_name, split in ds.items():
        print(f"  {split_name}: {len(split)} examples")
        print(f"  columns: {split.column_names}")

    # Save locally
    ds.save_to_disk(OUT_DIR)
    print(f"\nSaved to ./{OUT_DIR}/")
    print("Load later with: datasets.load_from_disk('./defactify_data')")


if __name__ == "__main__":
    main()
