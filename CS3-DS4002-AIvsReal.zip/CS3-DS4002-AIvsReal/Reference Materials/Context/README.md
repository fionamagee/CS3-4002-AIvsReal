# Context — Why AI-Image Detection Matters

These resources frame the social and technical importance of being able to distinguish real from AI-generated images.

1. **"How good are humans at detecting AI-generated images?"** — Roca et al., 2025.
   arXiv: https://arxiv.org/abs/2507.18640
   Establishes the ~62% human-detection baseline that this case study is targeting.

2. **"New research suggests folks are relying on outdated visual cues to identify AI-generated faces"** — PC Gamer, 2025.
   https://www.pcgamer.com/software/ai/new-research-suggests-folks-are-relying-on-outdated-visual-cues-to-identify-ai-generated-faces-but-i-did-get-14-20-on-the-test/
   Accessible introduction to why traditional cues (extra fingers, weird teeth) no longer work.

3. **"A survey on deep-learning-based techniques for detecting AI-generated synthetic images"** — Guevara, Sandoval Orozco & García Villalba, 2026.
   doi:10.3390/engproc2026123032
   Broad survey of detection approaches (pixel-domain, frequency-domain, semantic, ensemble).
