# Data Context — The Defactify Image Dataset and Its Generators

These resources explain where the data comes from and what the five generative models in it actually do.

1. **Defactify Image Dataset card** — Roy et al., 2026.
   https://huggingface.co/datasets/Rajarshi-Roy-research/Defactify_Image_Dataset
   Direct dataset link with column descriptions, license, and example images.

2. **"A Comprehensive Dataset for Human vs. AI Generated Image Detection"** — Roy et al., 2026.
   arXiv: https://arxiv.org/abs/2601.00553
   The paper introducing the Defactify dataset. Documents the captioning method, the generators used (SD2.1, SDXL, SD3, DALL·E 3, Midjourney), and benchmark results.

3. **MS COCO** — the source of the original captions used to generate the AI images.
   https://cocodataset.org
