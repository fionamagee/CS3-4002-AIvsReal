# Technical — How to Build the Models

These resources cover the architectures and training techniques used in this case study.

1. **EfficientNet (Tan & Le, 2019)** — the family of CNNs the case study recommends for transfer learning. https://arxiv.org/abs/1905.11946

2. **Vision Transformer (Dosovitskiy et al., 2020)** — the transformer architecture for image classification. https://arxiv.org/abs/2010.11929

3. **"AI-generated artwork detection using self-distilled transformers with global–local feature learning and Grad-CAM interpretability"** — Wang et al., 2026. doi:10.1038/s41598-025-29229-2

4. **"Advancing GAN deepfake detection: Mixed datasets and comprehensive artifact analysis"** — Say, Alkan & Kocak, 2025. doi:10.3390/app15020923

5. **PyTorch transfer learning tutorial** — https://pytorch.org/tutorials/beginner/transfer_learning_tutorial.html

6. **timm library** — easiest way to load EfficientNet and ViT with pretrained weights in PyTorch. https://github.com/huggingface/pytorch-image-models
